/**
 * Created by Administrator on 2015/8/6.
 */
$(document).ready(function(){
    $("#bar-1").click(function(){
        $(this).css({"border-bottom":"6px solid #fdfc00"});
        $("#bar-2").css({"border-bottom":"none"});
        $("#bar-3").css({"border-bottom":"none"});
        $("#bar-4").css({"border-bottom":"none"});
        $("#bar-5").css({"border-bottom":"none"});
        $("#bar-6").css({"border-bottom":"none"});

    });
    $("#bar-2").click(function(){
        $(this).css({"border-bottom":"6px solid #fdfc00"});
        $("#bar-1").css({"border-bottom":"none"});
        $("#bar-3").css({"border-bottom":"none"});
        $("#bar-4").css({"border-bottom":"none"});
        $("#bar-5").css({"border-bottom":"none"});
        $("#bar-6").css({"border-bottom":"none"});

    });
    $("#bar-3").click(function(){
        $(this).css({"border-bottom":"6px solid #fdfc00"});
        $("#bar-2").css({"border-bottom":"none"});
        $("#bar-1").css({"border-bottom":"none"});
        $("#bar-4").css({"border-bottom":"none"});
        $("#bar-5").css({"border-bottom":"none"});
        $("#bar-6").css({"border-bottom":"none"});

    });
    $("#bar-4").click(function(){
        $(this).css({"border-bottom":"6px solid #fdfc00"});
        $("#bar-2").css({"border-bottom":"none"});
        $("#bar-3").css({"border-bottom":"none"});
        $("#bar-1").css({"border-bottom":"none"});
        $("#bar-5").css({"border-bottom":"none"});
        $("#bar-6").css({"border-bottom":"none"});

    });
    $("#bar-5").click(function(){
        $(this).css({"border-bottom":"6px solid #fdfc00"});
        $(".m-hd").css({"display":" block"});
        $("#bar-2").css({"border-bottom":"none"});
        $("#bar-3").css({"border-bottom":"none"});
        $("#bar-4").css({"border-bottom":"none"});
        $("#bar-1").css({"border-bottom":"none"});
        $("#bar-6").css({"border-bottom":"none"});

    });
    $("#bar-6").click(function(){
        $(this).css({"border-bottom":"6px solid #fdfc00"});
        $("#bar-2").css({"border-bottom":"none"});
        $("#bar-3").css({"border-bottom":"none"});
        $("#bar-4").css({"border-bottom":"none"});
        $("#bar-5").css({"border-bottom":"none"});
        $("#bar-1").css({"border-bottom":"none"});

    });

})